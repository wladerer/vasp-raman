#!/bin/bash

DIR=$(pwd)

nderiv_step_size='2_0.01'

export VASP_RAMAN_RUN='aprun -B /u/afonari/vasp.5.3.2/vasp.5.3/vasp &> job.out'

# manually split modes
Modes[0]='01_10'
Modes[1]='11_20'
Modes[2]='21_29'

for m in ${Modes[*]}
do
    VASP_RAMAN_PARAMS="${m}_${nderiv_step_size}"
    export VASP_RAMAN_PARAMS=${VASP_RAMAN_PARAMS}
    #
    FOLDER="Modes_${VASP_RAMAN_PARAMS}"
    #
    echo "Running VASP in ${FOLDER}"
    #
    if [ -d "${FOLDER}" ]; then
        cd "${FOLDER}"
        qsub raman.sub
        cd ..
    else
        mkdir "${FOLDER}"
        cd "${FOLDER}"
        ln -s ../OUTCAR.phon ./OUTCAR.phon
        ln -s ../POSCAR.phon ./POSCAR.phon
        ln -s ../POTCAR ./POTCAR
        ln -s ../INCAR.raman ./INCAR
        ln -s ../raman.sub ./raman.sub
        ln -s ../KPOINTS ./KPOINTS
        qsub raman.sub
        cd ..
    fi
done
